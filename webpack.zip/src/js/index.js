         import Chart from 'chart.js/auto';
         import __  from 'moment';
         import ___ from'chartjs-adapter-moment';
         import annotationPlugin from 'chartjs-plugin-annotation';

         Chart.register(annotationPlugin);

         let asd=1.1
         let drt=document.body.clientWidth;
         if (drt>1000) asd=2.2;
         else if (drt>1200) asd=2.8;
         
         let ctx = document.getElementById("myChart");
                document.myChart = new Chart(ctx, {
                type: 'line',
                data: {
                  labels: [], 
                  datasets: [{
                    data: [],
                    lineTension: 0,
                    backgroundColor: 'transparent',
                    borderColor: '#007bff',
                    borderWidth: 4,
                    pointBackgroundColor: '#007bff'
                  }]
                },
                options: {
                  aspectRatio: asd,
                  scales: {
		    y: {
                        beginAtZero: false
                    },
	  	    x: {
                       type: 'time',
                       time: {    
			  distribution: 'linear',
			  unit: 'day',     
			  parser: 'DD.MM.YY',      
	                  displayFormats: {
                              'day': 'DD-MM-YY'
                          },
                       },
		       ticks: {
			 tickWidth: 10,
                         autoSkip: false,
                         maxRotation: 90,
                         minRotation: 90,
			 z: 100,
                         labelOffset: -8,
			 backdropPadding: 3       
	               }
		     }
                  },
		  layout: {
			padding: {
		   	     left: 2,
			     right: 10,
			     bottom: 2,
			     top: 5
			}
                  },
              plugins: {
                  legend: {
                    display: false
                },
	     annotation: {
		annotations: [{
		type: 'line',
	        yMin:    0,
                yMax:    0,
	        borderColor: 'tomato',
		borderWidth: 3
	       }]
              },
              tooltip: {
                 callbacks: {
                     title: function(tooltipItems) {
			var d=tooltipItems[0].parsed.x;
                        d=new Date(d);
                        return d.getDate()+"-"+(d.getMonth()+1)+"-"+(d.getYear()+1900);
                     }
                 } 
              },
	    }  
	 }});
        
         function formatDate(xlist){
		if (xlist[0].includes('-')) {  
		for (var i=0; i<xlist.length; i++){
		    var sa=xlist[i].split('-');
		    xlist[i]=sa[2]+'.'+sa[1]+'.'+sa[0].slice(-2);
		  }
		}
	 }

         function addData(alist,blist) {
	       formatDate(alist); 
               document.myChart.data.labels.push.apply(document.myChart.data.labels, alist);
               document.myChart.data.datasets.forEach((dataset) => {
               dataset.data.push.apply(dataset.data, blist);
               });
               document.myChart.update();		 
            }
         
           function removeData() {
                document.myChart.data.labels.length=0;
                document.myChart.data.datasets.forEach((dataset) => {
                dataset.data.length=0;
               });
            document.myChart.update();
            }
        
          
           let mkalist=function(ab_filter, list1, fortime){
	             if (list1.length==0) return;	 
		     var alist=[];
		     var blist=[];		       
		     alist=Object.keys(list1);
		     Object.values(list1).forEach(z=> blist.push(Math.round(z*100)/100));
		     alist=alist.slice(-1*ab_filter);	
		     blist=blist.slice(-1*ab_filter); 
		     //var qqt=Math.round(alist.length/10);
		     //if (qqt>1){
		     //	       alist = alist.filter(function(d, i){ return (i+1)%qqt == 0; });
	 	     //	       blist = blist.filter(function(d, i){ return (i+1)%qqt == 0; });
		     //}
		     removeData();
		     if(fortime){
		       document.myChart.options.scales.x.time.unit = "hour";
		       document.myChart.options.scales.x.time.parser = "HH:mm";
		     }
		     else{
		        document.myChart.options.scales.x.time.unit = "day";
	                document.myChart.options.scales.x.time.parser = "DD.MM.YY";
		     }
		     addData(alist,blist);
		     return false;		 
                }

	      let getdate = function(){
                 var dd=$("#datepicker").data('datepicker').getFormattedDate('yyyy-mm-dd');
		 // REDIRECT TO URL
		 window.location.replace(window.location.origin+"?d="+dd);		    
	      }     
	      
               
         //init all data
         mkalist(7, list);    
        

         $('#datepicker').datepicker({
             weekStart: 1,
             daysOfWeekHighlighted: "6,0",
             autoclose: true,
             todayHighlight: true,
         });
         $('#datepicker').datepicker("setDate", new Date());
	 if (Object.keys(list).length>0) $("#datepicker").datepicker("update", new Date(Object.keys(list).slice(-1)[0]));


         //prepare html
         document.mkalist = mkalist;
         document.getdate=getdate;
         feather.replace();         
